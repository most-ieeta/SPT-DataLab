Contains all dll's of sptMesh and a .jar pre compiled with a stable version of SPTDataLab that can be
executed via command line, without an IDE.